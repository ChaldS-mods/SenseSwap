package com.chalds.senseswap.server;

import com.chalds.senseswap.SenseSwapMod;
import com.chalds.senseswap.config.ModConfig;
import com.chalds.senseswap.network.RoleNetworking;
import com.chalds.senseswap.network.SummaryNetworking;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class PhaseManager {

    public enum Phase { GAME, REST }

    private Phase currentPhase = Phase.GAME;
    private long ticksRemaining;
    private int roundNumber = 1;

    private final Map<UUID, Integer> prevScores = new HashMap<>();

    private static PhaseManager instance = null;
    public static PhaseManager getInstance() { return instance; }
    public static PhaseManager start() { instance = new PhaseManager(); return instance; }
    public static void stop() { instance = null; }

    public PhaseManager() { this.ticksRemaining = getGameTicks(); }

    public Phase getCurrentPhase() { return currentPhase; }
    public long getTicksRemaining() { return ticksRemaining; }
    public int getRoundNumber() { return roundNumber; }

    public static long getGameTicks() { return (long) ModConfig.get().gamePhaseDurationMinutes * 60 * 20; }
    public static long getRestTicks()  { return (long) ModConfig.get().restPhaseDurationMinutes  * 60 * 20; }

    public void tick(MinecraftServer server, Map<UUID, SenseSwapMod.Role> playerRoles) {
        if (server.method_3760().method_14574() == 0) return;
        ticksRemaining--;
        if (ticksRemaining % 20 == 0) broadcastPhase(server);
        if (ticksRemaining <= 0) {
            if (currentPhase == Phase.GAME) enterRest(server, playerRoles);
            else enterGame(server, playerRoles);
        }
    }

    private void enterRest(MinecraftServer server, Map<UUID, SenseSwapMod.Role> playerRoles) {
        currentPhase = Phase.REST;
        ticksRemaining = getRestTicks();

        Map<UUID, Integer> before = new HashMap<>(ScoreManager.getAllScores());
        ScoreManager.awardRoundPoints(server, playerRoles);
        Map<UUID, Integer> after  = ScoreManager.getAllScores();

        List<SummaryNetworking.SummaryEntry> entries = new ArrayList<>();
        List<Map.Entry<UUID, Integer>> board = ScoreManager.getLeaderboard();
        for (Map.Entry<UUID, Integer> e : board) {
            class_3222 p = server.method_3760().method_14602(e.getKey());
            String name = p != null ? p.method_5477().getString() : ScoreManager.getPlayerName(e.getKey());
            SenseSwapMod.Role role = playerRoles.getOrDefault(e.getKey(), SenseSwapMod.Role.BLIND);
            int delta = e.getValue() - before.getOrDefault(e.getKey(), 0);
            entries.add(new SummaryNetworking.SummaryEntry(name, role, e.getValue(), delta));
        }

        for (class_3222 p : server.method_3760().method_14571()) {
            RoleNetworking.sendRoleClearToClient(p);
            SummaryNetworking.sendSummary(p, roundNumber, entries);
            p.method_7353(class_2561.method_43471("senseswap.phase.rest_start").method_27692(class_124.field_1075), false);
        }

        playerRoles.forEach((uuid, role) -> {});
        playerRoles.clear();
        RoleManager.saveRoles(server, playerRoles);
        broadcastPhase(server);
    }

    private void enterGame(MinecraftServer server, Map<UUID, SenseSwapMod.Role> playerRoles) {
        roundNumber++;
        currentPhase = Phase.GAME;
        ticksRemaining = getGameTicks();

        List<class_3222> players = new ArrayList<>(server.method_3760().method_14571());
        Collections.shuffle(players);

        boolean useDizzy = ModConfig.get().enableDizzyRole && players.size() >= 4;

        if (ModConfig.get().duoMode) {
            assignDuoRoles(server, playerRoles, players);
        } else {
            SenseSwapMod.Role[] roles = useDizzy
                ? new SenseSwapMod.Role[]{SenseSwapMod.Role.BLIND, SenseSwapMod.Role.DEAF,
                                           SenseSwapMod.Role.MUTE,  SenseSwapMod.Role.DIZZY}
                : new SenseSwapMod.Role[]{SenseSwapMod.Role.BLIND, SenseSwapMod.Role.DEAF,
                                           SenseSwapMod.Role.MUTE};
            for (int i = 0; i < roles.length && i < players.size(); i++) {
                playerRoles.put(players.get(i).method_5667(), roles[i]);
            }
        }

        for (class_3222 p : server.method_3760().method_14571()) {
            UUID uuid = p.method_5667();
            if (playerRoles.containsKey(uuid)) {
                RoleNetworking.sendRoleToClient(p, playerRoles.get(uuid));
            }
            p.method_7353(class_2561.method_43469("senseswap.phase.round_start", roundNumber)
                .method_27692(class_124.field_1060), false);
        }

        for (class_3222 p : server.method_3760().method_14571()) {
            RoleNetworking.sendPhaseToClient(p, currentPhase, ticksRemaining);
        }

        RoleManager.saveRoles(server, playerRoles);
    }

    private void assignDuoRoles(MinecraftServer server, Map<UUID, SenseSwapMod.Role> roles,
                                 List<class_3222> players) {
        String p1name = ModConfig.get().duoPlayer1;
        String p2name = ModConfig.get().duoPlayer2;

        SenseSwapMod.Role[] pool = {SenseSwapMod.Role.BLIND, SenseSwapMod.Role.DEAF,
                                     SenseSwapMod.Role.MUTE};
        List<SenseSwapMod.Role> shuffled = new ArrayList<>(List.of(pool));
        Collections.shuffle(shuffled);

        for (class_3222 p : players) {
            String name = p.method_5477().getString();
            if (name.equalsIgnoreCase(p1name)) roles.put(p.method_5667(), shuffled.get(0));
            else if (name.equalsIgnoreCase(p2name)) roles.put(p.method_5667(), shuffled.get(1));
        }
    }

    private void broadcastPhase(MinecraftServer server) {
        for (class_3222 p : server.method_3760().method_14571()) {
            RoleNetworking.sendPhaseToClient(p, currentPhase, ticksRemaining);
        }
    }
}
