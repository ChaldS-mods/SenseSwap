package com.chalds.senseswap.network;

import com.chalds.senseswap.SenseSwapMod;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import java.util.ArrayList;
import java.util.List;

public class SummaryNetworking {

    public record SummaryEntry(String name, SenseSwapMod.Role role, int score, int delta) {}

    public record SummaryPayload(int round, List<SummaryEntry> entries) implements class_8710 {
        public static final class_8710.class_9154<SummaryPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655("senseswap", "summary"));
        public static final class_9139<class_2540, SummaryPayload> CODEC = class_9139.method_56438(
            (val, buf) -> {
                buf.method_53002(val.round());
                buf.method_53002(val.entries().size());
                for (SummaryEntry e : val.entries()) {
                    buf.method_10814(e.name());
                    buf.method_10817(e.role());
                    buf.method_53002(e.score());
                    buf.method_53002(e.delta());
                }
            },
            buf -> {
                int round = buf.readInt();
                int sz = buf.readInt();
                List<SummaryEntry> list = new ArrayList<>(sz);
                for (int i = 0; i < sz; i++) {
                    list.add(new SummaryEntry(
                        buf.method_19772(),
                        buf.method_10818(SenseSwapMod.Role.class),
                        buf.readInt(),
                        buf.readInt()
                    ));
                }
                return new SummaryPayload(round, list);
            }
        );
        @Override public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public static void registerServer() {
        PayloadTypeRegistry.playS2C().register(SummaryPayload.ID, SummaryPayload.CODEC);
    }

    public static void sendSummary(class_3222 player, int round, List<SummaryEntry> entries) {
        ServerPlayNetworking.send(player, new SummaryPayload(round, entries));
    }
}
