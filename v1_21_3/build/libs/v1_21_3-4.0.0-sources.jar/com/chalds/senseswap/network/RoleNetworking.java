package com.chalds.senseswap.network;

import com.chalds.senseswap.SenseSwapMod;
import com.chalds.senseswap.server.PhaseManager;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public class RoleNetworking {

    // ── Пакет 1: Server→Client — назначить роль ───────────────────────────────
    public record RolePayload(SenseSwapMod.Role role) implements class_8710 {
        public static final class_8710.class_9154<RolePayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(SenseSwapMod.MOD_ID, "role"));
        public static final class_9139<class_2540, RolePayload> CODEC = class_9139.method_56438(
            (value, buf) -> buf.method_10817(value.role),
            buf -> new RolePayload(buf.method_10818(SenseSwapMod.Role.class))
        );
        @Override public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
    }

    // ── Пакет 2: Server→Client — убрать роль ─────────────────────────────────
    public record RoleClearPayload() implements class_8710 {
        public static final class_8710.class_9154<RoleClearPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(SenseSwapMod.MOD_ID, "role_clear"));
        public static final class_9139<class_2540, RoleClearPayload> CODEC = class_9139.method_56438(
            (value, buf) -> {},
            buf -> new RoleClearPayload()
        );
        @Override public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
    }

    // ── Пакет 3: Server→Client — фаза и таймер (для HUD) ─────────────────────
    public record PhasePayload(PhaseManager.Phase phase, long ticksRemaining) implements class_8710 {
        public static final class_8710.class_9154<PhasePayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(SenseSwapMod.MOD_ID, "phase"));
        public static final class_9139<class_2540, PhasePayload> CODEC = class_9139.method_56438(
            (value, buf) -> {
                buf.method_10817(value.phase);
                buf.method_52974(value.ticksRemaining);
            },
            buf -> new PhasePayload(
                buf.method_10818(PhaseManager.Phase.class),
                buf.readLong()
            )
        );
        @Override public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
    }

    // ── Пакет 4: Server→Client — игра остановлена, убрать таймер ─────────────
    public record PhaseStopPayload() implements class_8710 {
        public static final class_8710.class_9154<PhaseStopPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(SenseSwapMod.MOD_ID, "phase_stop"));
        public static final class_9139<class_2540, PhaseStopPayload> CODEC = class_9139.method_56438(
            (value, buf) -> {},
            buf -> new PhaseStopPayload()
        );
        @Override public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public static void registerServer() {
        PayloadTypeRegistry.playS2C().register(RolePayload.ID, RolePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(RoleClearPayload.ID, RoleClearPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(PhasePayload.ID, PhasePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(PhaseStopPayload.ID, PhaseStopPayload.CODEC);
    }

    public static void sendRoleToClient(class_3222 player, SenseSwapMod.Role role) {
        ServerPlayNetworking.send(player, new RolePayload(role));
    }

    public static void sendRoleClearToClient(class_3222 player) {
        ServerPlayNetworking.send(player, new RoleClearPayload());
    }

    public static void sendPhaseToClient(class_3222 player,
                                          PhaseManager.Phase phase, long ticksRemaining) {
        ServerPlayNetworking.send(player, new PhasePayload(phase, ticksRemaining));
    }

    public static void sendPhaseStopToClient(class_3222 player) {
        ServerPlayNetworking.send(player, new PhaseStopPayload());
    }
}
