package com.chalds.senseswap;

import com.chalds.senseswap.network.RoleNetworking;
import com.chalds.senseswap.server.PhaseManager;
import com.chalds.senseswap.server.RoleManager;
import com.chalds.senseswap.server.ScoreManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.*;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;

public class SenseSwapMod implements ModInitializer {

    public static final String MOD_ID = "senseswap";
    public static final String VERSION = "5.0.0";

    private static final Map<UUID, Role> playerRoles = new HashMap<>();
    private static boolean gameRunning = false;
    private static MinecraftServer server;
    private static long sessionStartTime = 0;

    public enum Role {
        BLIND("senseswap.role.blind"),
        DEAF("senseswap.role.deaf"),
        MUTE("senseswap.role.mute"),
        DIZZY("senseswap.role.dizzy");  // NEW in 4.0

        private final String translationKey;
        Role(String translationKey) { this.translationKey = translationKey; }
        public String getTranslationKey() { return translationKey; }
    }

    @Override
    public void onInitialize() {
        RoleNetworking.registerServer();
        com.chalds.senseswap.network.SummaryNetworking.registerServer();

        ServerLifecycleEvents.SERVER_STARTED.register(srv -> {
            server = srv;
            RoleManager.loadRoles(srv, playerRoles);
            ScoreManager.loadScores(srv);
            System.out.println("[SenseSwap] v" + VERSION + " Server initialized.");
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(srv -> {
            RoleManager.saveRoles(srv, playerRoles);
            ScoreManager.saveScores(srv);
            PhaseManager.stop();
        });

        ServerTickEvents.END_SERVER_TICK.register(srv -> {
            PhaseManager pm = PhaseManager.getInstance();
            if (pm != null) {
                pm.tick(srv, playerRoles);
            }
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, srv) -> {
            class_3222 player = handler.field_14140;
            UUID uuid = player.method_5667();

            if (playerRoles.containsKey(uuid)) {
                Role role = playerRoles.get(uuid);
                srv.execute(() -> {
                    RoleNetworking.sendRoleToClient(player, role);
                    player.method_7353(
                        class_2561.method_43469("senseswap.message.role_restored",
                            class_2561.method_43471(role.getTranslationKey()).method_27692(getRoleFormatting(role)))
                            .method_27692(class_124.field_1054),
                        false
                    );
                });
            }

            PhaseManager pm = PhaseManager.getInstance();
            if (pm != null) {
                srv.execute(() -> RoleNetworking.sendPhaseToClient(
                    player, pm.getCurrentPhase(), pm.getTicksRemaining()));
            }
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, srv) ->
            RoleManager.saveRoles(srv, playerRoles));

        // ── Команды ───────────────────────────────────────────────────────────
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                method_9247("ss")
                    .requires(source -> source.method_9259(2))

                    .then(method_9247("start")
                        .executes(ctx -> {
                            MinecraftServer s = ctx.getSource().method_9211();
                            List<class_3222> players = new ArrayList<>(s.method_3760().method_14571());

                            int minP = com.chalds.senseswap.config.ModConfig.get().duoMode ? 2 : com.chalds.senseswap.config.ModConfig.get().minPlayers;
                            if (players.size() < minP) {
                                ctx.getSource().method_9213(class_2561.method_43469("senseswap.command.need_players", minP));
                                return 0;
                            }

                            Collections.shuffle(players);
                            playerRoles.clear();

                            // 4.0: use DIZZY role if enabled and there are 4+ players
                            boolean useDizzy = com.chalds.senseswap.config.ModConfig.get().enableDizzyRole
                                && players.size() >= 4;
                            Role[] roles = useDizzy
                                ? new Role[]{Role.BLIND, Role.DEAF, Role.MUTE, Role.DIZZY}
                                : new Role[]{Role.BLIND, Role.DEAF, Role.MUTE};

                            for (int i = 0; i < roles.length && i < players.size(); i++) {
                                playerRoles.put(players.get(i).method_5667(), roles[i]);
                            }

                            gameRunning = true;
                            sessionStartTime = System.currentTimeMillis();

                            PhaseManager pm = null;
                            if (com.chalds.senseswap.config.ModConfig.get().phaseCycleEnabled) {
                                pm = PhaseManager.start();
                            }

                            broadcastRoles(s);
                            if (pm != null) {
                                final PhaseManager pmFinal = pm;
                                for (class_3222 p : s.method_3760().method_14571()) {
                                    RoleNetworking.sendPhaseToClient(p, pmFinal.getCurrentPhase(), pmFinal.getTicksRemaining());
                                }
                            }

                            RoleManager.saveRoles(s, playerRoles);

                            ctx.getSource().method_9226(() ->
                                class_2561.method_43471("senseswap.command.started").method_27692(class_124.field_1060), true);
                            return 1;
                        })
                    )

                    .then(method_9247("stop")
                        .executes(ctx -> {
                            MinecraftServer s = ctx.getSource().method_9211();
                            playerRoles.clear();
                            gameRunning = false;
                            sessionStartTime = 0;
                            PhaseManager.stop();

                            for (class_3222 player : s.method_3760().method_14571()) {
                                RoleNetworking.sendRoleClearToClient(player);
                                RoleNetworking.sendPhaseStopToClient(player);
                            }

                            RoleManager.saveRoles(s, playerRoles);
                            ctx.getSource().method_9226(() ->
                                class_2561.method_43471("senseswap.command.stopped").method_27692(class_124.field_1061), true);
                            return 1;
                        })
                    )

                    // ── NEW 4.0: /ss swap — randomly shuffle roles between players ──
                    .then(method_9247("swap")
                        .executes(ctx -> {
                            MinecraftServer s = ctx.getSource().method_9211();
                            if (playerRoles.isEmpty()) {
                                ctx.getSource().method_9213(class_2561.method_43471("senseswap.command.no_roles"));
                                return 0;
                            }

                            List<UUID> uuids = new ArrayList<>(playerRoles.keySet());
                            List<Role> roles = new ArrayList<>(playerRoles.values());
                            Collections.shuffle(roles);
                            for (int i = 0; i < uuids.size(); i++) {
                                playerRoles.put(uuids.get(i), roles.get(i));
                            }

                            broadcastRoles(s);
                            RoleManager.saveRoles(s, playerRoles);

                            ctx.getSource().method_9226(() ->
                                class_2561.method_43471("senseswap.command.swapped").method_27692(class_124.field_1076), true);
                            return 1;
                        })
                    )

                    .then(method_9247("setrole")
                        .then(method_9244("player", StringArgumentType.word())
                            .then(method_9244("role", StringArgumentType.word())
                                .executes(ctx -> {
                                    MinecraftServer s = ctx.getSource().method_9211();
                                    String playerName = StringArgumentType.getString(ctx, "player");
                                    String roleName = StringArgumentType.getString(ctx, "role").toUpperCase();
                                    class_3222 target = s.method_3760().method_14566(playerName);
                                    if (target == null) {
                                        ctx.getSource().method_9213(class_2561.method_43469("senseswap.command.player_not_found", playerName));
                                        return 0;
                                    }
                                    Role role;
                                    try { role = Role.valueOf(roleName); }
                                    catch (IllegalArgumentException e) {
                                        ctx.getSource().method_9213(class_2561.method_43469("senseswap.command.invalid_role", roleName));
                                        return 0;
                                    }
                                    playerRoles.put(target.method_5667(), role);
                                    RoleNetworking.sendRoleToClient(target, role);
                                    RoleManager.saveRoles(s, playerRoles);
                                    ctx.getSource().method_9226(() ->
                                        class_2561.method_43469("senseswap.command.role_set",
                                            target.method_5477(),
                                            class_2561.method_43471(role.getTranslationKey()).method_27692(getRoleFormatting(role)))
                                            .method_27692(class_124.field_1060), true);
                                    return 1;
                                })
                            )
                        )
                    )

                    .then(method_9247("clearrole")
                        .then(method_9244("player", StringArgumentType.word())
                            .executes(ctx -> {
                                MinecraftServer s = ctx.getSource().method_9211();
                                String playerName = StringArgumentType.getString(ctx, "player");
                                class_3222 target = s.method_3760().method_14566(playerName);
                                if (target == null) {
                                    ctx.getSource().method_9213(class_2561.method_43469("senseswap.command.player_not_found", playerName));
                                    return 0;
                                }
                                playerRoles.remove(target.method_5667());
                                RoleNetworking.sendRoleClearToClient(target);
                                RoleManager.saveRoles(s, playerRoles);
                                ctx.getSource().method_9226(() ->
                                    class_2561.method_43469("senseswap.command.role_cleared", target.method_5477())
                                        .method_27692(class_124.field_1054), true);
                                return 1;
                            })
                        )
                    )

                    .then(method_9247("status")
                        .executes(ctx -> {
                            MinecraftServer s = ctx.getSource().method_9211();
                            ctx.getSource().method_9226(() ->
                                class_2561.method_43471("senseswap.command.status_header").method_27692(class_124.field_1065), false);

                            if (playerRoles.isEmpty()) {
                                ctx.getSource().method_9226(() ->
                                    class_2561.method_43471("senseswap.command.no_roles").method_27692(class_124.field_1080), false);
                            } else {
                                for (Map.Entry<UUID, Role> entry : playerRoles.entrySet()) {
                                    class_3222 p = s.method_3760().method_14602(entry.getKey());
                                    String name = p != null ? p.method_5477().getString() : entry.getKey().toString();
                                    Role role = entry.getValue();
                                    ctx.getSource().method_9226(() ->
                                        class_2561.method_43470("  " + name + " → ")
                                            .method_10852(class_2561.method_43471(role.getTranslationKey())
                                                .method_27692(getRoleFormatting(role))), false);
                                }
                            }

                            PhaseManager pm = PhaseManager.getInstance();
                            if (pm != null) {
                                long ticks = pm.getTicksRemaining();
                                long mins = (ticks / 20) / 60;
                                long secs = (ticks / 20) % 60;
                                String phaseName = pm.getCurrentPhase() == PhaseManager.Phase.GAME
                                    ? "GAME" : "REST";
                                ctx.getSource().method_9226(() ->
                                    class_2561.method_43470("  Фаза: " + phaseName + " | Осталось: " + mins + ":" + String.format("%02d", secs)
                                        + " | Раунд: " + pm.getRoundNumber())
                                        .method_27692(class_124.field_1075), false);
                            } else if (gameRunning && sessionStartTime > 0) {
                                long elapsed = (System.currentTimeMillis() - sessionStartTime) / 1000;
                                long minutes = elapsed / 60, seconds = elapsed % 60;
                                ctx.getSource().method_9226(() ->
                                    class_2561.method_43469("senseswap.command.session_time", minutes, seconds)
                                        .method_27692(class_124.field_1075), false);
                            }
                            return 1;
                        })
                    )

                    .then(method_9247("list").executes(ctx -> {
                        MinecraftServer s = ctx.getSource().method_9211();
                        if (playerRoles.isEmpty()) {
                            ctx.getSource().method_9226(() ->
                                class_2561.method_43471("senseswap.command.no_roles").method_27692(class_124.field_1080), false);
                            return 1;
                        }
                        for (Map.Entry<UUID, Role> entry : playerRoles.entrySet()) {
                            class_3222 p = s.method_3760().method_14602(entry.getKey());
                            String name = p != null ? p.method_5477().getString() : entry.getKey().toString();
                            Role role = entry.getValue();
                            ctx.getSource().method_9226(() ->
                                class_2561.method_43470("  " + name + " → ")
                                    .method_10852(class_2561.method_43471(role.getTranslationKey())
                                        .method_27692(getRoleFormatting(role))), false);
                        }
                        return 1;
                    }))

                    .then(method_9247("reload").executes(ctx -> {
                        MinecraftServer s = ctx.getSource().method_9211();
                        playerRoles.clear();
                        RoleManager.loadRoles(s, playerRoles);
                        broadcastRoles(s);
                        ctx.getSource().method_9226(() ->
                            class_2561.method_43471("senseswap.command.reloaded").method_27692(class_124.field_1060), true);
                        return 1;
                    }))

                    // ── NEW 4.0: /ss score — show leaderboard ─────────────────────────
                    .then(method_9247("score")
                        .executes(ctx -> {
                            MinecraftServer s = ctx.getSource().method_9211();
                            ctx.getSource().method_9226(() ->
                                class_2561.method_43471("senseswap.command.score_header").method_27692(class_124.field_1065), false);

                            List<Map.Entry<UUID, Integer>> board = ScoreManager.getLeaderboard();
                            if (board.isEmpty()) {
                                ctx.getSource().method_9226(() ->
                                    class_2561.method_43471("senseswap.command.score_empty").method_27692(class_124.field_1080), false);
                            } else {
                                int[] rank = {1};
                                for (Map.Entry<UUID, Integer> entry : board) {
                                    String name = ScoreManager.getPlayerName(entry.getKey());
                                    int pts = entry.getValue();
                                    String medal = rank[0] == 1 ? "🥇" : rank[0] == 2 ? "🥈" : rank[0] == 3 ? "🥉" : "  ";
                                    ctx.getSource().method_9226(() ->
                                        class_2561.method_43470(medal + " " + rank[0] + ". " + name + " — " + pts + " pts")
                                            .method_27692(rank[0] == 1 ? class_124.field_1054 : class_124.field_1068), false);
                                    rank[0]++;
                                }
                            }
                            return 1;
                        })
                    )

                    // ── NEW 4.0: /ss score reset ──────────────────────────────────────
                    .then(method_9247("score")
                        .then(method_9247("reset")
                            .executes(ctx -> {
                                MinecraftServer s = ctx.getSource().method_9211();
                                ScoreManager.resetScores(s);
                                ctx.getSource().method_9226(() ->
                                    class_2561.method_43471("senseswap.command.score_reset").method_27692(class_124.field_1061), true);
                                return 1;
                            })
                        )
                    )

                    // ── NEW 4.0: /ss score add <player> <points> ──────────────────────
                    .then(method_9247("score")
                        .then(method_9247("add")
                            .then(method_9244("player", StringArgumentType.word())
                                .then(method_9244("points", IntegerArgumentType.integer())
                                    .executes(ctx -> {
                                        MinecraftServer s = ctx.getSource().method_9211();
                                        String playerName = StringArgumentType.getString(ctx, "player");
                                        int pts = IntegerArgumentType.getInteger(ctx, "points");
                                        class_3222 target = s.method_3760().method_14566(playerName);
                                        if (target == null) {
                                            ctx.getSource().method_9213(class_2561.method_43469("senseswap.command.player_not_found", playerName));
                                            return 0;
                                        }
                                        ScoreManager.addPoints(target.method_5667(), target.method_5477().getString(), pts);
                                        ScoreManager.saveScores(s);
                                        ctx.getSource().method_9226(() ->
                                            class_2561.method_43469("senseswap.command.score_added", target.method_5477(), pts)
                                                .method_27692(class_124.field_1060), true);
                                        return 1;
                                    })
                                )
                            )
                        )
                    )
            );
        });

        System.out.println("[SenseSwap] v" + VERSION + " initialized (server-authoritative, phase cycle, scores, dizzy role).");
    }

    public static Role getRoleForPlayer(UUID uuid) { return playerRoles.get(uuid); }
    public static boolean isGameRunning() { return gameRunning; }
    public static Map<UUID, Role> getPlayerRoles() { return playerRoles; }

    private static void broadcastRoles(MinecraftServer s) {
        for (class_3222 player : s.method_3760().method_14571()) {
            UUID uuid = player.method_5667();
            if (playerRoles.containsKey(uuid)) {
                RoleNetworking.sendRoleToClient(player, playerRoles.get(uuid));
            } else {
                RoleNetworking.sendRoleClearToClient(player);
            }
        }
    }

    public static class_124 getRoleFormatting(Role role) {
        return switch (role) {
            case BLIND -> class_124.field_1061;
            case DEAF  -> class_124.field_1078;
            case MUTE  -> class_124.field_1060;
            case DIZZY -> class_124.field_1076;  // NEW
        };
    }
}
