package com.chalds.senseswap.gui;

import com.chalds.senseswap.config.ModConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class DuoSetupScreen extends class_437 {

    private final class_437 parent;
    private class_342 player1Field;
    private class_342 player2Field;
    private boolean duoEnabled;
    private String statusMsg = "";

    public DuoSetupScreen(class_437 parent) {
        super(class_2561.method_43470("Режим 2 игроков"));
        this.parent     = parent;
        this.duoEnabled = ModConfig.get().duoMode;
    }

    @Override
    protected void method_25426() {
        int cx = field_22789 / 2, cy = field_22790 / 2;

        player1Field = new class_342(field_22793, cx - 100, cy - 40, 200, 20,
            class_2561.method_43470("Игрок 1"));
        player1Field.method_47404(class_2561.method_43470("Ник игрока 1"));
        player1Field.method_1852(ModConfig.get().duoPlayer1);

        player2Field = new class_342(field_22793, cx - 100, cy, 200, 20,
            class_2561.method_43470("Игрок 2"));
        player2Field.method_47404(class_2561.method_43470("Ник игрока 2"));
        player2Field.method_1852(ModConfig.get().duoPlayer2);

        method_37063(player1Field);
        method_37063(player2Field);

        method_37063(class_4185.method_46430(
            class_2561.method_43470(duoEnabled ? "§a✔ Дуэт вкл" : "§c✘ Дуэт выкл"),
            btn -> {
                duoEnabled = !duoEnabled;
                btn.method_25355(class_2561.method_43470(duoEnabled ? "§a✔ Дуэт вкл" : "§c✘ Дуэт выкл"));
            }
        ).method_46434(cx - 60, cy + 35, 120, 20).method_46431());

        method_37063(class_4185.method_46430(
            class_2561.method_43470("Сохранить"),
            btn -> save()
        ).method_46434(cx - 60, cy + 65, 120, 20).method_46431());

        method_37063(class_4185.method_46430(
            class_2561.method_43471("senseswap.gui.cancel"),
            btn -> method_25419()
        ).method_46434(cx - 60, cy + 92, 120, 20).method_46431());
    }

    private void save() {
        ModConfig cfg = ModConfig.get();
        cfg.duoMode    = duoEnabled;
        cfg.duoPlayer1 = player1Field.method_1882().trim();
        cfg.duoPlayer2 = player2Field.method_1882().trim();
        cfg.save();
        statusMsg = "§aSохранено!";
    }

    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        method_25420(ctx, mx, my, delta);

        int cx = field_22789 / 2, cy = field_22790 / 2;
        ctx.method_25294(cx - 140, cy - 80, cx + 140, cy + 120, 0xDD0D0A06);
        ctx.method_49601(cx - 140, cy - 80, 280, 200, 0xFFD4AF37);

        ctx.method_51448().method_22903();
        ctx.method_51448().method_46416(cx, cy - 65, 0);
        ctx.method_51448().method_22905(1.3f, 1.3f, 1f);
        ctx.method_27534(field_22793, class_2561.method_43470("Дуэт-режим"), 0, 0, 0xFFD700);
        ctx.method_51448().method_22909();

        ctx.method_27535(field_22793, class_2561.method_43470("Игрок 1:"), cx - 100, cy - 52, 0xAAAAAA);
        ctx.method_27535(field_22793, class_2561.method_43470("Игрок 2:"), cx - 100, cy - 12, 0xAAAAAA);

        if (!statusMsg.isEmpty()) {
            ctx.method_27534(field_22793, class_2561.method_43470(statusMsg), cx, cy + 115, 0xFFFFFF);
        }

        super.method_25394(ctx, mx, my, delta);
    }

    @Override public boolean method_25421() { return false; }
}
