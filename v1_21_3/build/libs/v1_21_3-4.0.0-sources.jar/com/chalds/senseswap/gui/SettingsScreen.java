package com.chalds.senseswap.gui;

import com.chalds.senseswap.config.ModConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5676;

public class SettingsScreen extends class_437 {

    private final class_437 parent;
    private ModConfig config;

    private float tempHudScale;
    private int tempBlindStrength;
    private float tempFogIntensity;
    private int tempPopupDuration;
    private ModConfig.HudPosition tempPosition;
    private boolean tempHudEnabled;
    private boolean tempAutoAssign;
    private boolean tempShowPopup;
    private boolean tempPhaseCycleEnabled;
    private int tempGameMinutes;
    private int tempRestMinutes;

    public SettingsScreen(class_437 parent) {
        super(class_2561.method_43471("senseswap.gui.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        config = ModConfig.get();
        tempHudScale = config.hudScale;
        tempBlindStrength = config.blindEffectStrength;
        tempFogIntensity = config.fogIntensity;
        tempPopupDuration = config.rolePopupDuration;
        tempPosition = config.hudPosition;
        tempHudEnabled = config.hudEnabled;
        tempAutoAssign = config.autoAssignRoles;
        tempShowPopup = config.showRolePopup;
        tempPhaseCycleEnabled = config.phaseCycleEnabled;
        tempGameMinutes = config.gamePhaseDurationMinutes;
        tempRestMinutes = config.restPhaseDurationMinutes;

        int centerX = this.field_22789 / 2;
        int btnW = 310;
        int btnH = 20;
        int gap = 26;
        int x = centerX - btnW / 2;

        // ── Visual section ────────────────────────────────────────────────────
        int y = 42;

        method_37063(class_5676.method_32613(tempHudEnabled)
            .method_32617(x, y, btnW, btnH,
                class_2561.method_43471("senseswap.gui.hud_enabled"),
                (btn, val) -> tempHudEnabled = val));

        method_37063(class_5676.<ModConfig.HudPosition>method_32606(pos ->
                    class_2561.method_43471("senseswap.gui.hud_pos_" + pos.name().toLowerCase()))
                .method_32624(ModConfig.HudPosition.values())
                .method_32619(tempPosition)
                .method_32617(x, y + gap, btnW, btnH,
                    class_2561.method_43471("senseswap.gui.hud_position"),
                    (btn, val) -> tempPosition = val));

        method_37063(new class_357(x, y + gap * 2, btnW, btnH,
                class_2561.method_43470(""), (tempHudScale - 0.5f) / 1.5f) {
            @Override protected void method_25346() {
                method_25355(class_2561.method_43471("senseswap.gui.hud_scale")
                    .method_10852(class_2561.method_43470(": " + String.format("%.1f", tempHudScale))));
            }
            @Override protected void method_25344() { tempHudScale = (float)(field_22753 * 1.5f + 0.5f); }
        });

        method_37063(new class_357(x, y + gap * 3, btnW, btnH,
                class_2561.method_43470(""), tempFogIntensity) {
            @Override protected void method_25346() {
                method_25355(class_2561.method_43471("senseswap.gui.fog_intensity")
                    .method_10852(class_2561.method_43470(": " + String.format("%.0f%%", tempFogIntensity * 100))));
            }
            @Override protected void method_25344() { tempFogIntensity = (float) field_22753; }
        });

        // ── Game section ──────────────────────────────────────────────────────
        int gameY = y + gap * 4 + 16;

        method_37063(new class_357(x, gameY, btnW, btnH,
                class_2561.method_43470(""), (tempBlindStrength - 1) / 9.0) {
            @Override protected void method_25346() {
                method_25355(class_2561.method_43471("senseswap.gui.blind_effect")
                    .method_10852(class_2561.method_43470(": " + tempBlindStrength)));
            }
            @Override protected void method_25344() { tempBlindStrength = (int)(field_22753 * 9) + 1; }
        });

        method_37063(class_5676.method_32613(tempAutoAssign)
            .method_32617(x, gameY + gap, btnW, btnH,
                class_2561.method_43471("senseswap.gui.auto_assign"),
                (btn, val) -> tempAutoAssign = val));

        method_37063(class_5676.method_32613(tempShowPopup)
            .method_32617(x, gameY + gap * 2, btnW, btnH,
                class_2561.method_43471("senseswap.gui.show_role_popup"),
                (btn, val) -> tempShowPopup = val));

        method_37063(new class_357(x, gameY + gap * 3, btnW, btnH,
                class_2561.method_43470(""), (tempPopupDuration - 1) / 14.0) {
            @Override protected void method_25346() {
                method_25355(class_2561.method_43471("senseswap.gui.role_popup_duration")
                    .method_10852(class_2561.method_43470(": " + tempPopupDuration + "s")));
            }
            @Override protected void method_25344() { tempPopupDuration = (int)(field_22753 * 14) + 1; }
        });

        // ── Phase cycle section ───────────────────────────────────────────────
        int phaseY = gameY + gap * 4 + 16;

        method_37063(class_5676.method_32613(tempPhaseCycleEnabled)
            .method_32617(x, phaseY, btnW, btnH,
                class_2561.method_43471("senseswap.gui.phase_cycle_enabled"),
                (btn, val) -> tempPhaseCycleEnabled = val));

        // Game phase: 5–60 минут
        method_37063(new class_357(x, phaseY + gap, btnW, btnH,
                class_2561.method_43470(""), (tempGameMinutes - 5) / 55.0) {
            @Override protected void method_25346() {
                method_25355(class_2561.method_43471("senseswap.gui.game_phase_duration")
                    .method_10852(class_2561.method_43470(": " + tempGameMinutes + " min")));
            }
            @Override protected void method_25344() {
                tempGameMinutes = (int)(field_22753 * 55) + 5;
            }
        });

        // Rest phase: 1–10 минут
        method_37063(new class_357(x, phaseY + gap * 2, btnW, btnH,
                class_2561.method_43470(""), (tempRestMinutes - 1) / 9.0) {
            @Override protected void method_25346() {
                method_25355(class_2561.method_43471("senseswap.gui.rest_phase_duration")
                    .method_10852(class_2561.method_43470(": " + tempRestMinutes + " min")));
            }
            @Override protected void method_25344() {
                tempRestMinutes = (int)(field_22753 * 9) + 1;
            }
        });

        // ── Buttons ───────────────────────────────────────────────────────────
        int bottomY = this.field_22790 - 30;

        method_37063(class_4185.method_46430(class_2561.method_43471("senseswap.gui.done"), btn -> {
            applyAndSave();
            this.field_22787.method_1507(parent);
        }).method_46434(centerX - 155, bottomY, 100, btnH).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43471("senseswap.gui.reset"), btn -> {
            config.resetToDefault();
            this.field_22787.method_1507(new SettingsScreen(parent));
        }).method_46434(centerX - 50, bottomY, 100, btnH).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43471("senseswap.gui.cancel"), btn -> {
            this.field_22787.method_1507(parent);
        }).method_46434(centerX + 55, bottomY, 100, btnH).method_46431());
    }

    private void applyAndSave() {
        config.hudEnabled = tempHudEnabled;
        config.hudScale = tempHudScale;
        config.hudPosition = tempPosition;
        config.blindEffectStrength = tempBlindStrength;
        config.fogIntensity = tempFogIntensity;
        config.autoAssignRoles = tempAutoAssign;
        config.showRolePopup = tempShowPopup;
        config.rolePopupDuration = tempPopupDuration;
        config.phaseCycleEnabled = tempPhaseCycleEnabled;
        config.gamePhaseDurationMinutes = tempGameMinutes;
        config.restPhaseDurationMinutes = tempRestMinutes;
        config.save();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25420(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);

        int centerX = this.field_22789 / 2;
        int gap = 26;
        int sectionGameY  = 42 + gap * 4 + 16;
        int sectionPhaseY = sectionGameY + gap * 4 + 16;

        context.method_27534(field_22793, this.field_22785, centerX, 10, 0xFFFFFF);

        context.method_27534(field_22793,
            class_2561.method_43471("senseswap.gui.section_visual"), centerX, 30, 0xFFD700);

        context.method_27534(field_22793,
            class_2561.method_43471("senseswap.gui.section_game"), centerX, sectionGameY - 12, 0xFFD700);

        context.method_27534(field_22793,
            class_2561.method_43471("senseswap.gui.section_phase"), centerX, sectionPhaseY - 12, 0xFFD700);
    }
}
