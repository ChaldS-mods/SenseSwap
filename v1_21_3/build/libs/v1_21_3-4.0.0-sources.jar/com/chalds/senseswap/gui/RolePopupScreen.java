package com.chalds.senseswap.gui;

import com.chalds.senseswap.SenseSwapMod;
import com.chalds.senseswap.config.ModConfig;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class RolePopupScreen extends class_437 {

    private final SenseSwapMod.Role role;
    private final class_437 parent;
    private int ticksRemaining;

    public RolePopupScreen(SenseSwapMod.Role role, class_437 parent) {
        super(class_2561.method_43471("senseswap.popup.title"));
        this.role = role;
        this.parent = parent;
        this.ticksRemaining = ModConfig.get().rolePopupDuration * 20;
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        method_37063(class_4185.method_46430(
            class_2561.method_43471("senseswap.gui.done"),
            btn -> this.field_22787.method_1507(parent)
        ).method_46434(centerX - 50, centerY + 60, 100, 20).method_46431());
    }

    @Override
    public void method_25393() {
        ticksRemaining--;
        if (ticksRemaining <= 0) {
            this.field_22787.method_1507(parent);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xAA000000);
        super.method_25394(context, mouseX, mouseY, delta);

        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;

        int boxW = 300;
        int boxH = 120;
        int boxX = centerX - boxW / 2;
        int boxY = centerY - boxH / 2;

        context.method_25294(boxX, boxY, boxX + boxW, boxY + boxH, 0xDD1A1A2E);
        context.method_49601(boxX, boxY, boxW, boxH, 0xFFFFD700);

        int roleColor = switch (role) {
            case BLIND -> 0xFF5555; case DIZZY -> 0xCC55FF;
            case DEAF -> 0x5555FF;
            case MUTE -> 0x55FF55;
        };

        String roleStr = class_2561.method_43471(role.getTranslationKey()).getString().toUpperCase();

        context.method_27534(field_22793,
            class_2561.method_43471("senseswap.popup.title").method_27692(class_124.field_1068),
            centerX, boxY + 15, 0xFFFFFF);

        context.method_51448().method_22903();
        context.method_51448().method_46416(centerX, boxY + 45, 0);
        context.method_51448().method_22905(2.5f, 2.5f, 1.0f);
        context.method_27534(field_22793, class_2561.method_43470(roleStr), 0, 0, roleColor);
        context.method_51448().method_22909();

        String descKey = switch (role) {
            case BLIND -> "senseswap.popup.desc.blind";
            case DEAF  -> "senseswap.popup.desc.deaf";
            case MUTE  -> "senseswap.popup.desc.mute";
            case DIZZY -> "senseswap.popup.desc.dizzy";
        };
        context.method_27534(field_22793,
            class_2561.method_43471(descKey).method_27692(class_124.field_1080),
            centerX, boxY + 90, 0xAAAAAA);

        int secs = ticksRemaining / 20 + 1;
        context.method_27534(field_22793,
            class_2561.method_43469("senseswap.popup.closes", secs).method_27692(class_124.field_1063),
            centerX, centerY + 70, 0x888888);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
