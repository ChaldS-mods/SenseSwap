package com.chalds.senseswap.gui;

import com.chalds.senseswap.SenseSwapMod;
import java.util.List;
import java.util.Random;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class DaySummaryScreen extends class_437 {

    private static final class_2960 BG_TEX =
        class_2960.method_60655("senseswap", "textures/summary_bg.png");
    private static final class_2960[] BADGE_TEX = {
        class_2960.method_60655("senseswap", "textures/role_badge_blind.png"),
        class_2960.method_60655("senseswap", "textures/role_badge_deaf.png"),
        class_2960.method_60655("senseswap", "textures/role_badge_mute.png"),
        class_2960.method_60655("senseswap", "textures/role_badge_dizzy.png"),
    };

    public record PlayerEntry(String name, SenseSwapMod.Role role, int score, int delta) {}

    private final int roundNumber;
    private final List<PlayerEntry> entries;
    private final class_437 parent;

    private int   tick         = 0;
    private float scrollOpen   = 0f;
    private float[] rowReveal;
    private Particle[] particles;
    private final Random rng = new Random();

    private static class Particle {
        float x, y, vx, vy, life, maxLife;
        int color;
        Particle(float x, float y, float vx, float vy, float life, int col) {
            this.x=x; this.y=y; this.vx=vx; this.vy=vy;
            this.life=this.maxLife=life; this.color=col;
        }
        void tick() { x+=vx; y+=vy; vy+=0.12f; vx*=0.96f; life-=1f; }
        boolean dead() { return life<=0; }
    }

    private static final int[] CONFETTI = {
        0xFFD700, 0xFF5555, 0x55AAFF, 0x55FF88, 0xCC55FF, 0xFF8844
    };

    public DaySummaryScreen(int round, List<PlayerEntry> entries, class_437 parent) {
        super(class_2561.method_43473());
        this.roundNumber = round;
        this.entries     = entries;
        this.parent      = parent;
        this.rowReveal   = new float[Math.max(entries.size(), 1)];
        this.particles   = new Particle[0];
    }

    @Override
    protected void method_25426() {
        int bw = 120, bh = 22;
        method_37063(class_4185.method_46430(
            class_2561.method_43471("senseswap.gui.done"),
            b -> method_25419()
        ).method_46434(field_22789/2 - bw/2, field_22790/2 + 210, bw, bh).method_46431());
    }

    @Override
    public void method_25393() {
        tick++;

        // Phase 1: scroll unfurl (0-30 ticks)
        scrollOpen = Math.min(scrollOpen + 0.045f, 1f);

        // Phase 2: rows cascade in after scroll is ~60% open
        if (scrollOpen > 0.6f) {
            float rowBase = (scrollOpen - 0.6f) / 0.4f;
            for (int i = 0; i < rowReveal.length; i++) {
                float target = Math.max(0f, rowBase - i * 0.22f);
                rowReveal[i] = Math.min(rowReveal[i] + 0.055f, Math.min(target, 1f));
            }
        }

        // Phase 3: confetti burst once fully open
        if (scrollOpen >= 1f && tick == 30) {
            spawnConfetti();
        }

        java.util.ArrayList<Particle> alive = new java.util.ArrayList<>();
        for (Particle p : particles) {
            p.tick();
            if (!p.dead()) alive.add(p);
        }
        particles = alive.toArray(new Particle[0]);
    }

    private void spawnConfetti() {
        int cx = field_22789 / 2;
        int cy = field_22790 / 2 - 180;
        java.util.ArrayList<Particle> list = new java.util.ArrayList<>();
        for (int i = 0; i < 80; i++) {
            float ang = (float)(Math.PI * 2 * rng.nextFloat());
            float spd = 1.5f + rng.nextFloat() * 5f;
            int col   = CONFETTI[rng.nextInt(CONFETTI.length)];
            list.add(new Particle(
                cx + (rng.nextFloat()-0.5f)*60,
                cy + (rng.nextFloat()-0.5f)*20,
                (float)Math.cos(ang)*spd,
                (float)Math.sin(ang)*spd - 2.5f,
                25f + rng.nextFloat()*35f, col));
        }
        particles = list.toArray(new Particle[0]);
    }

    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        ctx.method_25294(0, 0, field_22789, field_22790, 0xBB000000);

        int bgW = 700, bgH = 520;
        int bgX = field_22789/2  - bgW/2;
        int bgY = field_22790/2 - bgH/2;

        // scroll unfurl: clip height
        float unroll  = easeOutBack(scrollOpen);
        int   clipH   = (int)(bgH * unroll);
        int   clipY   = bgY + bgH/2 - clipH/2;

        if (clipH < 4) {
            super.method_25394(ctx, mx, my, delta);
            return;
        }

        // scale Y so it looks like unrolling from center
        ctx.method_51448().method_22903();
        ctx.method_51448().method_46416(field_22789/2f, field_22790/2f, 0);
        ctx.method_51448().method_22905(1f, unroll, 1f);
        ctx.method_51448().method_46416(-field_22789/2f, -field_22790/2f, 0);

        ctx.method_25290(net.minecraft.class_1921::method_62277, BG_TEX, bgX, bgY, 0f, 0f, bgW, bgH, bgW, bgH);
        ctx.method_51448().method_22909();

        // contents only when sufficiently open
        if (scrollOpen > 0.55f) {
            float contentAlpha = (scrollOpen - 0.55f) / 0.45f;
            int   cAlpha       = (int)(contentAlpha * 255f);

            renderTitle(ctx, bgX, bgY, bgW, cAlpha);
            renderRows(ctx, bgX, bgY, bgW, cAlpha);
            renderFooter(ctx, bgX, bgY, bgW, bgH, cAlpha);
        }

        renderParticles(ctx);
        super.method_25394(ctx, mx, my, delta);
    }

    private void renderTitle(class_332 ctx, int bgX, int bgY, int bgW, int alpha) {
        String title = "ИТОГИ РАУНДА " + roundNumber;
        int a = Math.min(alpha, 255);

        ctx.method_51448().method_22903();
        ctx.method_51448().method_46416(bgX + bgW/2f, bgY + 56, 0);
        ctx.method_51448().method_22905(1.55f, 1.55f, 1f);
        ctx.method_27534(field_22793,
            class_2561.method_43470(title), 0, 0, (a << 24) | 0xFFD700);
        ctx.method_51448().method_22909();
    }

    private void renderRows(class_332 ctx, int bgX, int bgY, int bgW, int baseAlpha) {
        int rowY0 = bgY + 108;
        int rowH  = 88;
        int badgeS = 52;

        for (int i = 0; i < Math.min(entries.size(), 4); i++) {
            float rev = rowReveal[i];
            if (rev <= 0.01f) continue;

            int   alpha = (int)(rev * Math.min(baseAlpha, 255));
            PlayerEntry e = entries.get(i);
            int ey = rowY0 + i * rowH;

            // row slide-in from right
            int slideX = (int)((1f - easeOut(rev)) * 80f);

            ctx.method_51448().method_22903();
            ctx.method_51448().method_46416(slideX, 0, 0);

            // badge
            int bx = bgX + 22;
            int by = ey + (rowH - badgeS) / 2 - 2;
            ctx.method_25290(net.minecraft.class_1921::method_62277, BADGE_TEX[e.role().ordinal() % 4], bx, by, 0f, 0f, badgeS, badgeS, badgeS, badgeS);

            // medal
            String medal = switch (i) {
                case 0 -> "1.";
                case 1 -> "2.";
                case 2 -> "3.";
                default -> "4.";
            };
            int medalColor = switch (i) {
                case 0 -> 0xFFD700;
                case 1 -> 0xCCCCCC;
                case 2 -> 0xCD7F32;
                default -> 0x888888;
            };

            // player name
            ctx.method_27535(field_22793,
                class_2561.method_43470(medal + " " + e.name()),
                bgX + 82, ey + 18,
                (alpha << 24) | medalColor);

            // role name
            String roleName = class_2561.method_43471(e.role().getTranslationKey()).getString();
            ctx.method_27535(field_22793,
                class_2561.method_43470(roleName),
                bgX + 82, ey + 34,
                (alpha << 24) | (getRoleRgb(e.role()) & 0xFFFFFF));

            // score
            String scoreStr = e.score() + " pts";
            ctx.method_27535(field_22793,
                class_2561.method_43470(scoreStr),
                bgX + bgW - 120, ey + 22,
                (alpha << 24) | 0xFFD700);

            // delta
            if (e.delta() > 0) {
                ctx.method_27535(field_22793,
                    class_2561.method_43470("+" + e.delta()),
                    bgX + bgW - 120, ey + 38,
                    (alpha << 24) | 0x55FF88);
            }

            // progress bar
            int barX = bgX + 82, barY = ey + 54;
            int barW = bgW - 220;
            int maxScore = entries.stream().mapToInt(PlayerEntry::score).max().orElse(1);
            int filled = (int)(barW * rev * (e.score() / (float) Math.max(maxScore, 1)));
            int roleRgb = getRoleRgb(e.role());

            ctx.method_25294(barX, barY, barX + barW, barY + 7,
                ((alpha / 3) << 24) | 0x333333);
            ctx.method_25294(barX, barY, barX + filled, barY + 7,
                (alpha << 24) | (roleRgb & 0xFFFFFF));
            // shine
            ctx.method_25294(barX, barY, barX + filled, barY + 3,
                ((alpha / 2) << 24) | 0xFFFFFF);

            ctx.method_51448().method_22909();
        }
    }

    private void renderFooter(class_332 ctx, int bgX, int bgY, int bgW, int bgH, int alpha) {
        int a = Math.min(alpha, 255);
        ctx.method_27534(field_22793,
            class_2561.method_43470("SenseSwap  ·  конец раунда"),
            bgX + bgW/2, bgY + bgH - 34,
            (a << 24) | 0xC8A850);
    }

    private void renderParticles(class_332 ctx) {
        for (Particle p : particles) {
            float t   = p.life / p.maxLife;
            int alpha = (int)(t * 220f);
            int argb  = (alpha << 24) | (p.color & 0xFFFFFF);
            int sz    = Math.max(2, (int)(t * 5f));
            int sx    = (int)p.x, sy = (int)p.y;
            ctx.method_25294(sx - sz/2, sy - sz/2, sx + sz/2, sy + sz/2, argb);
        }
    }

    private float easeOutBack(float t) {
        float c1 = 1.70158f, c3 = c1 + 1f;
        float v = 1f + c3 * (float)Math.pow(t - 1, 3) + c1 * (float)Math.pow(t - 1, 2);
        return Math.max(0f, Math.min(1f, v));
    }

    private float easeOut(float t) {
        return 1f - (1f - t) * (1f - t);
    }

    private int getRoleRgb(SenseSwapMod.Role r) {
        return switch (r) {
            case BLIND -> 0xFF5555;
            case DEAF  -> 0x55AAFF;
            case MUTE  -> 0x55FF88;
            case DIZZY -> 0xCC55FF;
        };
    }

    @Override public boolean method_25421() { return false; }
}
