package com.chalds.senseswap;

import com.chalds.senseswap.config.ModConfig;
import com.chalds.senseswap.gui.*;
import com.chalds.senseswap.network.RoleNetworking;
import com.chalds.senseswap.network.SummaryNetworking;
import com.chalds.senseswap.server.PhaseManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class SenseSwapClientMod implements ClientModInitializer {

    public static SenseSwapMod.Role currentRole = null;
    public static PhaseManager.Phase currentPhase = null;
    public static long phaseTicksRemaining = 0;
    public static float fadeFraction = 0f;

    private static class_304 settingsKey;
    private static class_304 duoKey;

    @Override
    public void onInitializeClient() {
        ModConfig.load();

        settingsKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "senseswap.key.open_settings",
            class_3675.class_307.field_1668, GLFW.GLFW_KEY_K, "senseswap.key.category"));

        duoKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "senseswap.key.duo_setup",
            class_3675.class_307.field_1668, GLFW.GLFW_KEY_Y, "senseswap.key.category"));

        ClientPlayNetworking.registerGlobalReceiver(
            RoleNetworking.RolePayload.ID,
            (payload, context) -> {
                SenseSwapMod.Role role = payload.role();
                context.client().execute(() -> {
                    currentRole = role;
                    if (role != null && ModConfig.get().showRolePopup) {
                        class_310 mc = class_310.method_1551();
                        if (ModConfig.get().useWheelAnimation) {
                            mc.method_1507(new WheelSpinScreen(role, mc.field_1755));
                        } else {
                            mc.method_1507(new RolePopupScreen(role, mc.field_1755));
                        }
                    }
                });
            }
        );

        ClientPlayNetworking.registerGlobalReceiver(
            RoleNetworking.RoleClearPayload.ID,
            (payload, context) -> context.client().execute(() -> currentRole = null));

        ClientPlayNetworking.registerGlobalReceiver(
            RoleNetworking.PhasePayload.ID,
            (payload, context) -> context.client().execute(() -> {
                currentPhase = payload.phase();
                phaseTicksRemaining = payload.ticksRemaining();
            }));

        ClientPlayNetworking.registerGlobalReceiver(
            RoleNetworking.PhaseStopPayload.ID,
            (payload, context) -> context.client().execute(() -> {
                currentPhase = null;
                phaseTicksRemaining = 0;
                fadeFraction = 0f;
            }));

        ClientPlayNetworking.registerGlobalReceiver(
            SummaryNetworking.SummaryPayload.ID,
            (payload, context) -> context.client().execute(() -> {
                class_310 mc = class_310.method_1551();
                List<DaySummaryScreen.PlayerEntry> entries = new ArrayList<>();
                for (SummaryNetworking.SummaryEntry e : payload.entries()) {
                    entries.add(new DaySummaryScreen.PlayerEntry(
                        e.name(), e.role(), e.score(), e.delta()));
                }
                mc.method_1507(new DaySummaryScreen(payload.round(), entries, mc.field_1755));
            }));

        HudRenderCallback.EVENT.register((context, tickDelta) ->
            RoleHudRenderer.render(context, tickDelta));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (currentPhase != null && phaseTicksRemaining > 0) {
                phaseTicksRemaining--;
                long total = currentPhase == PhaseManager.Phase.GAME
                    ? PhaseManager.getGameTicks() : PhaseManager.getRestTicks();
                long fadeTicks = 100L;
                fadeFraction = phaseTicksRemaining < fadeTicks
                    ? 1f - (phaseTicksRemaining / (float) fadeTicks) : 0f;
            }

            while (settingsKey.method_1436()) {
                client.method_1507(new SettingsScreen(client.field_1755));
            }
            while (duoKey.method_1436()) {
                client.method_1507(new DuoSetupScreen(client.field_1755));
            }
        });

        System.out.println("[SenseSwap] v" + SenseSwapMod.VERSION + " Client v5 initialized.");
    }
}
